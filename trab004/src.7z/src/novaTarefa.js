import React, { useState } from 'react';



const NovaTarefa = ({ onEnvio }) => {

    const [novoItem, setNovoItem] = useState('');

    function setNovaTarefa({target}) {
        setNovoItem(target.value);
    }

    function envio(e) {
        e.preventDefault();
        onEnvio(novoItem);
    }

    return (
        <div>
            <form onEnvio={envio}>
                <input className="Todo-input" placeholder="Digite uma nova tarefa" onChange={setNovaTarefa} />

                <button type="submit">Inserir</button>
            </form>
        </div>
    )

};

export default NovaTarefa;