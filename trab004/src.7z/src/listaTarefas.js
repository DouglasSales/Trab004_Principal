import React from 'react';


const Lista = ({ onChange, onDelete, value }) => {
    return (
        <div className="Item-container">
            <input className="Item-field" value={value} onChange={onChange} />        
            <button onClick={onDelete}>Deletar</button>
        </div>    
    );
};


export default Lista;