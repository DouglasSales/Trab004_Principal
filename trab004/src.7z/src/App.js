import { useState } from 'react';
import './App.css';
import listaTarefas from './listaTarefas'
import NovaTarefa from './novaTarefa';

const App = () => {
  const [tarefas, setTarefa] = useState([]);

  function adicionarNovaTarefa(tarefa) {
    const itensCopia = Array.from(tarefas);
    itensCopia.push({ id: tarefas.length, value: tarefa });
    setTarefa(itensCopia);
  }

  function AtualizaTarefa({ target}, index) {
    const itensCopia = Array.from(tarefas);
    itensCopia.splice(index, 1, {id: index, value: target.value });
    setTarefa(itensCopia);
  }

  function deletaTarefa(index) {
    const itensCopia = Array.from(tarefas);
    itensCopia.splice(index, 1);
    setTarefa(itensCopia);
  }

  return (
    <div className="App">
      <div className="App=header">
        <NovaTarefa onEnvio={adicionarNovaTarefa}/>
        {tarefas.map(({id, value}, index) => (
          <listaTarefas key={id} value={value} 
          onChange={(event) => AtualizaTarefa(event, index)}
          onDeleta={() => deletaTarefa(index)} />
        ))}        
      </div>

      <div className="Array-preview">
        <pre>
          {JSON.stringify(tarefas, null, 4)}
        </pre>
      </div>
    </div>
  )


}

/*function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}*/

export default App;
